import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import React from "react";
// import { createStore } from "redux";
import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { Provider } from "react-redux";
import allReducers from "./screens/store/reducers";
import "expo-dev-client";

import { useFonts } from "expo-font";

import Index from "./screens/Index";
const App = () => {
  const store = configureStore({ reducer: allReducers });
  const [fontsLoaded] = useFonts({
    nyala: require("./assets/fonts/nyala.ttf"),
    monsterBold: require("./assets/fonts/Montserrat-Bold.ttf"),
    monsterRegular: require("./assets/fonts/Montserrat-Regular.ttf"),
    signature: require("./assets/fonts/signature.ttf"),
    eman: require("./assets/fonts/Eman.otf"),
  });

  if (!fontsLoaded) {
    return <React.Fragment />;
  }

  return (
    <Provider store={store}>
      <Index />
    </Provider>
  );
};
export default App;
